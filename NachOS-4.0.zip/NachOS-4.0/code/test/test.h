#define ConsoleInput 0
#define ConsoleOutput 1  
#define MaxFileLength 255
#define BufferSize 255 